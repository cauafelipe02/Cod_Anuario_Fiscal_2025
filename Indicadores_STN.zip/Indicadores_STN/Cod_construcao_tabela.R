library(dplyr)
library(readxl)
library(readr)
library(janitor)
library(tidyr)

# Captura de dados --------------------------------------------------------

base_dados1 <- read_excel("Chaves_municipios - nomes, RD, codigo IBGE.xls")
rgf1 <- read.csv("RGF.csv")

# Manipulação da base dados ----------------------------------------------------

base_limpa1 <- base_dados1 |> 
  clean_names()

base_limpa1 <- base_limpa1 |> 
  rename(
    Cod_ibge = codigo_municipio_completo_ibge,
    Municipio = nome_municipio,
    RD = numero_rd_pe
  ) |> 
  select(
    Cod_ibge,
    Municipio,
    RD
  ) |> 
  filter(
    Cod_ibge != "2605459"
  )

# Filtragem do RGF --------------------------------------------------------

rgf1_limpo <- rgf1 |> 
  filter(
    cod_conta %in% c("DividaConsolidada", "ReceitaCorrenteLiquidaLimiteLegal"), #Seleciona as 2 contas necessárias
    stringr::str_detect(anexo, "RGF")
  ) |> 
  group_by(cod_ibge, cod_conta) |> 
  mutate(
    prioridade = case_when(     #Adiciona uma prioridade onde se não houver Q3 ele pega o S2
      periodicidade == "Q" & periodo == 3 ~ 1, #Prioriza o Q(quadrimestral 3)
      periodicidade == "S" & periodo == 2 ~ 2, #Se não houver pega o Semestral 2
      periodicidade == "Q" & periodo == 2 ~ 3, #Se não houver Q3 pega o Q2
      TRUE ~ 99
    )
  ) |> 
  slice_min(order_by = prioridade, n = 1, with_ties = FALSE) |> #Reduz pegando o menor número (maior prioridade)
  ungroup() |> 
  select(cod_ibge, cod_conta, valor) |> #Seleciona os campos que eu preciso
  pivot_wider(   #Separa as colunas de Divida e Receita                        
    names_from = cod_conta,   #Seleciona a coluna que possui os dois valores (Divida e Receita)
    values_from = valor       #Separa pelo seu valor
  ) |>  
  #Cria a coluna endividamento fazendo a divisão das duas colunas
  mutate(
    endividamento = DividaConsolidada / ReceitaCorrenteLiquidaLimiteLegal
  ) |> 
  rename(Cod_ibge = cod_ibge)

# Junção da base final + tabela de endividamento --------------------------------

# Garantir que o código do IBGE seja do mesmo tipo (character) em ambas as bases
base_limpa1 <- base_limpa1 |> mutate(Cod_ibge = as.character(Cod_ibge))
rgf1_limpo  <- rgf1_limpo  |> mutate(Cod_ibge = as.character(Cod_ibge))

#Faz a junção
base_STN <- left_join(base_limpa1, rgf1_limpo, by = "Cod_ibge") |> 
  rename(
    Divida_consolidada = DividaConsolidada, 
    Receita_Corrente = ReceitaCorrenteLiquidaLimiteLegal,
    indicador_1 = endividamento
    )